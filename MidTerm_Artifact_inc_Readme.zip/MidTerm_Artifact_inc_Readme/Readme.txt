# Midterm Team Assignment cm1040-webdev-t1g0-yed-team15-tg02
UOL: CM1040 Web Development 

## Members
- Abiodun Quadri Adekunle (@Quadri)
- Rui Caneira (@Rui Caneira)
- Akira SAKAGUCHI (@Akira Sakaguchi)

*On the team but not contributed (no response from the beginning until now..)
- Philipp A. Gerken
- Siyuan Ji

## URL of the website
https://hub.coursera-apps.org:443/connect/sharedrreubnpe?forceRefresh=false&path=%2F

## Files
 - src
   - StyleSheet
     - slider.css
     - style.css
   - images
     - (this dir contains images used in the HTML files)
 - attractions.html
 - index.html
 - services.html
 - MidTerm_Wireframes.pdf
 
## Working Links on the Website
- "Space Warriors Icon" -> index.html
- "Attractions" -> attractions.html 
- "Services" -> services.html

## Docs

### Team Work 1 
Google Doc - https://docs.google.com/document/d/1TM3XTzS-jHbTuv0-nfarEP0nph9dBV8fzxDv3Th5vKw/edit#
Wireframe - https://docs.google.com/presentation/d/14cTKkgStyIPKaMKLdJb1eDOViRzSaX8z4GSpHdkvQBI/edit#slide=id.p

## Team Work 2  
Google Doc - https://docs.google.com/document/d/1EXWfN6egSDjuYhW9hr2uy1Sgz_lzvpmf_rbCXiCqSr8/edit#heading=h.wx0m714xgbhp
HTML Wireframe - https://docs.google.com/presentation/d/14cTKkgStyIPKaMKLdJb1eDOViRzSaX8z4GSpHdkvQBI/edit#slide=id.gdc2266c543_0_15

## Team Work 3
Google Doc - https://docs.google.com/document/d/1LwEYz0lQgT-N1N2XVYgL2kaPhzWI_5PlZhL-_UrGfdI/edit#heading=h.2d0hgrjwz7iv
HTML Wireframe With CSS Markup - https://docs.google.com/presentation/d/1GCRgqE_-kgBDUFBchiBXWKzjbLgHmHuKXqOMsZlM82I/edit#slide=id.p

## Team Work 4
Google Doc - https://docs.google.com/document/d/1oYWBP6iCu2ZNTP56VDhln5VY7p8cOx5uzthpKYdhpaY/edit#
HTML Wireframe With CSS Markup - https://docs.google.com/presentation/d/1GCRgqE_-kgBDUFBchiBXWKzjbLgHmHuKXqOMsZlM82I/edit#slide=id.p
