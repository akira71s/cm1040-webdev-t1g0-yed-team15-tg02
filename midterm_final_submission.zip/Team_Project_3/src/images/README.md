<!--
author: Rui Caneira 29/05/2021
last updated by: Abiodun Q. Adekunle 13/06/2021
description: folder used to store images for the website
-->

INDEX PAGE
Icon --> icon_space_warriors.png
Carousel --> SpaceWarriors01.jpg, SpaceWarriors02.jpg, SpaceWarriors03.jpg

<!-- Abiodun Q. Adekunle -->
Icon --> icon_space_warriors_small.png
Background --> pages_background.jpg, space_warriors_footer_background.png